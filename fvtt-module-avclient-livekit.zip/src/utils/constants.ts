export const MODULE_NAME = "avclient-livekit";
export const LANG_NAME = "LIVEKITAVCLIENT";
export const LOG_PREFIX = "LiveKitAVClient |";
export const TAVERN_AUTH_SERVER = "https://patreon-auth.tavern.at";
