import "./utils/hooks";
import LiveKitAVClient from "./LiveKitAVClient";

CONFIG.WebRTC.clientClass = LiveKitAVClient;
